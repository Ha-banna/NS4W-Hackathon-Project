# RCNN-Style Object Detection (Notebook)

This repository contains a self-contained Jupyter notebook (`rcnn.ipynb`) that demonstrates an RCNN-style object detection workflow using region proposals (Selective Search), a CNN-based classifier/regressor, and post-processing (NMS + bounding-box decoding).
---

## Features

- **Region proposal** via `selectivesearch`
- **PyTorch model** (`RCNN` class) with classification + bounding-box regression heads
- **Training loop** with separate location/regression losses
- **IoU utilities** and non-maximum suppression
- **Inference/demo** (`test_predictions`) for visualizing predictions on an image

---

## Dataset

This project uses the **[Open Images Bus Trucks Dataset](https://www.kaggle.com/datasets/sixhky/open-images-bus-trucks)** from Kaggle, which is a curated subset of the Open Images dataset containing images of **buses and trucks** for object detection tasks.

The dataset includes:
- RGB images with bounding box annotations
- Classes: `Bus`, `Truck`
- Format: CSV annotation files (image IDs, bounding boxes, labels)
- License: CC BY 4.0 (as per Kaggle dataset license)

### Download Instructions

1. Visit the Kaggle dataset page:  
 [https://www.kaggle.com/datasets/sixhky/open-images-bus-trucks](https://www.kaggle.com/datasets/sixhky/open-images-bus-trucks)

2. Download the dataset ZIP file and extract it into a local folder, for example:

---

## Notebook Contents

- `ImagesData`, `RCNNDataset`: dataset utilities (cropping ROIs, packing labels/deltas)
- `extract_candidates`: Selective Search region proposals
- `extract_iou`: IoU computation helpers
- `preprocess_image`: basic preprocessing
- `decode`: apply predicted deltas to ROIs to get final boxes
- `train_batch`, `validate_batch`: training/evaluation steps
- `test_predictions`: run inference and draw boxes on a sample image

---

## Quickstart

### 1) Environment

```bash
# Python 3.10+ recommended
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

pip install -r requirements.txt
# For torch/torchvision, consult https://pytorch.org/get-started/locally/ for the wheel matching your CUDA/CPU.
