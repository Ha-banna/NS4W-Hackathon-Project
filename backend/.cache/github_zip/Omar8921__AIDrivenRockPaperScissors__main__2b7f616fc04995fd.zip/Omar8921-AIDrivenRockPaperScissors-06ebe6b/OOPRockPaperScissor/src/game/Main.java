package game;

import gameComponents.Logic;

public class Main {

	public static void main(String[] args) {
		Logic gameLogic = new Logic();
		gameLogic.startGame();

	}

}
