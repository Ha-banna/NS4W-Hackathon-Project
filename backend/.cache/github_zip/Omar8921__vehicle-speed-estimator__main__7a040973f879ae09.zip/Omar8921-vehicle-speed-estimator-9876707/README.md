# Vehicle Speed Estimator with YOLOv8 and Perspective Transform

This project estimates the speed of vehicles in a video using YOLOv8 for detection, ByteTrack for tracking, and a custom perspective transformation to project vehicle movement into a top-down space for accurate speed measurement.

---

## Features

- Detects and tracks cars, buses, and trucks using YOLOv8 and ByteTrack.
- Applies a perspective transformation to normalize road geometry.
- Estimates speed (in km/h) based on vertical displacement in bird’s-eye view.
- Visualizes bounding boxes, speed labels, object traces, and zone polygon.
- Automatically annotates vehicles with consistent tracking colors.

---

## Requirements

- Python 3.8+
- OpenCV
- Ultralytics
- Supervision
- NumPy

You can install the dependencies using:

```bash
pip install -r requirements.txt
```

---

## Usage

### Run the script

```bash
python main.py --source path_to_video.mp4
```

- Default video source is `vehicles.mp4` if not specified.
- Press `Q` to exit the visualization window.

---

## How It Works

1. **Detection & Tracking**:
   - YOLOv8 detects vehicles each frame.
   - ByteTrack assigns consistent IDs to each vehicle.

2. **Polygon Zone Filtering**:
   - Only objects inside the defined polygon are considered for speed.

3. **Perspective Transformation**:
   - A transformation matrix maps the trapezoidal road area into a vertical rectangle (top-down view).
   - Movement in Y-axis becomes proportional to actual distance.

4. **Speed Calculation**:
   - For each vehicle, the system tracks the last N Y-positions (N = FPS).
   - Speed is estimated as `distance / time`, converted to km/h.
   - The label is updated once enough position data is available.

---

## File Structure

- `main.py` — Main script with detection, tracking, transformation, and visualization.
- `vehicles.mp4` — Example input video (you can use your own).
- `README.md` — You’re reading it.

---

## Notes

- Assumes 1 pixel in the transformed space ≈ 1 meter for simplicity.
- You may calibrate the transformation more precisely using real-world road dimensions.
- This project uses only vertical movement (Y-axis) for estimating speed in the projected view.

---

## License

This project is for educational and research use. You are free to modify and adapt it as needed.
