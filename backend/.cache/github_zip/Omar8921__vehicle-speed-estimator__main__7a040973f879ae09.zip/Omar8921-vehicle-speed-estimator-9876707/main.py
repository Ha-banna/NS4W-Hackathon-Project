import argparse
import supervision as sv
import cv2
from ultralytics import YOLO
import numpy as np
from collections import deque, defaultdict

SOURCE = np.array([
    [1252, 787],
    [2208, 803],
    [5039, 2159],
    [-550, 2159]
])

TARGET_WIDTH = 25
TARGET_HEIGHT = 250

TARGET = np.array([
    [0,0],
    [TARGET_WIDTH - 1, 0],
    [TARGET_WIDTH - 1, TARGET_HEIGHT - 1],
    [0, TARGET_HEIGHT - 1]
])

class ViewTransformer:
    def __init__(self, source: np.ndarray, target: np.ndarray):
        source = source.astype(np.float32)
        target = target.astype(np.float32)
        self.m = cv2.getPerspectiveTransform(source, target)

    def transform_points(self, points: np.ndarray):
        reshaped_points = points.reshape(-1, 1, 2).astype(np.float32)
        transformed_points = cv2.perspectiveTransform(reshaped_points, self.m)
        return transformed_points.reshape(-1, 2)

cv2.namedWindow('Window')

def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', help='Path to the source video file', default='vehicles.mp4')
    args = vars(parser.parse_args())
    return args

if __name__ == '__main__':
    args = parse_arguments()
    video_path = args['source']
    video_info = sv.VideoInfo.from_video_path(video_path)
    
    frame_generator = sv.get_video_frames_generator(video_path)
    model = YOLO('yolov8x.pt')

    view_transformer = ViewTransformer(source=SOURCE, target=TARGET)

    tracker = sv.ByteTrack(frame_rate=video_info.fps)
    tracker.reset()

    valid_classes = ['car', 'bus', 'truck']

    thickness = sv.calculate_optimal_line_thickness(resolution_wh=video_info.resolution_wh)
    text_scale = sv.calculate_optimal_text_scale(resolution_wh=video_info.resolution_wh)

    label_annotator = sv.LabelAnnotator(text_scale=text_scale, text_position=sv.Position.BOTTOM_CENTER, text_thickness=thickness, color_lookup=sv.ColorLookup.TRACK)
    bounding_box_annotator = sv.BoundingBoxAnnotator(thickness=thickness, color_lookup=sv.ColorLookup.TRACK)
    trace_annotator = sv.TraceAnnotator(thickness=thickness, trace_length=video_info.fps * 2, position=sv.Position.BOTTOM_CENTER, color_lookup=sv.ColorLookup.TRACK)

    polygon_zone = sv.PolygonZone(SOURCE)

    coordinates = defaultdict(lambda: deque(maxlen=video_info.fps))

    for frame in frame_generator:
        result = model(frame)[0]
        detections = sv.Detections.from_ultralytics(result)

        mask = [cls in valid_classes for cls in detections.data['class_name']]
        detections = detections[mask]
        
        detections = tracker.update_with_detections(detections)
        detections = detections[polygon_zone.trigger(detections)]

        points = detections.get_anchors_coordinates(anchor=sv.Position.BOTTOM_CENTER)
        points = view_transformer.transform_points(points).astype(int)

        labels = []
        for tracker_id, (_, y) in zip(detections.tracker_id ,points):
            coordinates[tracker_id].append(y)

            if len(coordinates[tracker_id]) < video_info.fps / 2:
                labels.append(f'#{tracker_id}')
            else:
                coordinate_start = coordinates[tracker_id][0]
                coordinate_end = coordinates[tracker_id][-1]
                distance = abs(coordinate_end - coordinate_start)
                time = len(coordinates[tracker_id]) / video_info.fps
                speed = distance / time * 3.6
                labels.append(f'#{tracker_id} {int(speed)} km/h')

        annotated_frame = frame.copy()
        annotated_frame = trace_annotator.annotate(annotated_frame, detections)
        annotated_frame = bounding_box_annotator.annotate(annotated_frame, detections)
        annotated_frame = label_annotator.annotate(annotated_frame, detections, labels)

        display_frame = cv2.resize(annotated_frame, (1280, 720))  # Resize to a manageable size
        cv2.imshow('Window', display_frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()
